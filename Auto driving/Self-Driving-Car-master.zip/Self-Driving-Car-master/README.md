# Self-Driving-Car
This project uses image processing to  detect lanes and based on the slope of lines detected  moves left or right.
